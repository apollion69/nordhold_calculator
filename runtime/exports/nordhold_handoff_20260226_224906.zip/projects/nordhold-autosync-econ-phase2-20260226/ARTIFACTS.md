# ARTIFACTS.md

Updated: 2026-02-26 22:05 MSK

## Final Artifacts
- Canonical sync updates:
  - `TASKS.md` (`T53` moved to `completed`),
  - `STATUS.md` (T53 final live update with validation snapshot),
  - `DECISIONS.md` (`D-039` API additions + backward compatibility policy).
- Project tracker updates:
  - `PROJECT.md` (finalized state),
  - `PROJECT_TODO.md` (all items checked),
  - `DONE.md` (final closure checklist).

## Validation Command List (T53)
- `py_compile` run: `OK`.
- `unittest` run: `40 tests OK` (`skipped=7`, `FastAPI` missing).
- `web build` run: `OK`.
- `exe smoke` HTTP checks: endpoints returned `200`.

## Validation Command List (T54 continuation)
- `/mnt/c/Users/lenovo/Documents/cursor/.venv/Scripts/python.exe -m unittest -v tests.test_api_contract tests.test_replay_live tests.test_live_memory_v1 tests.test_realtime_engine tests.test_golden_regression`
  - result: `40 tests`, `OK (skipped=1)`,
  - skip reason: missing `httpx` for one Starlette TestClient-dependent test.
- Script assets added:
  - `codex/projects/nordhold/scripts/run_nordhold_live_soak.ps1`
  - `codex/projects/nordhold/scripts/stop_nordhold_live_soak.ps1`
- Script smoke run:
  - command:
    - `powershell -ExecutionPolicy Bypass -File scripts/run_nordhold_live_soak.ps1 -DurationS 5 -PollMs 500 -NoAutoconnect`
  - summary:
    - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_190246.summary.json`
  - key metric:
    - `endpoint_cycle_failures=0`

## T55 Closure Artifacts
- Pre-closure acceptance QA:
  - `codex/projects/nordhold/worklogs/t55-post-t54-acceptance/t55-acceptance-20260226_192346/acceptance_summary.json`
  - result: `overall_pass=true` (`py_compile`, `unittest`, `web_build`, `exe_smoke` all pass).
- Full soak summary:
  - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_193004.summary.json`
  - key metrics:
    - `endpoint_cycle_failures=0`,
    - `status_not_memory_count=1800`,
    - `memory_connected_false_count=1800`,
    - `last_mode=degraded`,
    - `last_reason=memory_unavailable_no_replay`,
    - `max_cycle_latency_ms=64.3`.

## T56 Blocker Artifacts (`run_id=20260226_203000`)
- Blocker summary:
  - game process exists: `NordHold.exe` (`pid=9364`),
  - autoconnect result: `mode=degraded`, `reason=process_found_but_admin_required`, `memory_connected=false`,
  - full `DurationS=1800` soak: `NOT_STARTED` (precheck blocker).
- Primary evidence:
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/REPORT.md`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/03_diagnostic_attempt.json`
- Additional run artifacts:
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/00_precheck_command_output.log`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/01_process_check.json`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/02_precheck_result.json`

## T56 Partial Soak Artifacts (`run_id=20260226_212616`)
- Partial-run summary:
  - precheck passed: `mode=memory`, `reason=ok`, `memory_connected=true`,
  - target duration: `1800s`,
  - interrupted by user at `1627s` (not completed),
  - `summary.json`: `NOT_GENERATED`,
  - status at capture:
    - `mode=degraded`,
    - `reason=memory_snapshot_failed:ReadProcessMemory failed: addr=0x56ad0004 size=4 read=0 winerr=299`,
    - `memory_connected=false`.
- Primary evidence:
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/PARTIAL_REPORT.md`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/PARTIAL_REPORT.json`
- Additional run artifacts:
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/02_precheck_result.json`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/10_soak_stdout.log`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/11_current_status.json`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_212653.launcher.out.log`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_212653.launcher.err.log`

## T56 Soak Runner Hardening Artifacts
- Hardened runner smoke:
  - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_220452.summary.json`
  - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_220452.partial.json`
- Change scope:
  - `codex/projects/nordhold/scripts/run_nordhold_live_soak.ps1`
  - added per-cycle checkpoint writes and interrupt-safe final summary persistence.
