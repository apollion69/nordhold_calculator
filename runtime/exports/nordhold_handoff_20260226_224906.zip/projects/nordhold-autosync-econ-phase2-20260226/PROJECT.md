# PROJECT.md

Updated: 2026-02-26 22:05 MSK

## T53 Overview
- Task: `T53` Nordhold autosync econ phase2 swarm implementation.
- Owner: `codex`.
- Merge windows: `backend+sim` -> `frontend` -> `packaging/docs`.

## Final State
- T53 finalized and marked `completed` in `TASKS.md`.
- Implemented blocks fixed in canonical records:
  - backend autoconnect/dataset/run-state/events,
  - sim economy model/totals,
  - frontend autoconnect + SSE + cards,
  - packaging/docs updates.

## Validation Snapshot
- `py_compile`: `OK`.
- `unittest`: `40 tests OK` (`skipped=7`, `FastAPI` missing).
- `web build`: `OK`.
- `exe smoke endpoints`: `200`.

## Post-T53 Continuation (T54)
- Added reusable soak scripts:
  - `scripts/run_nordhold_live_soak.ps1`
  - `scripts/stop_nordhold_live_soak.ps1`
- Updated docs:
  - `README.md` (live soak section),
  - `RUNBOOK.md` (live soak procedure).
- Revalidated core suite on Windows `.venv`:
  - `40 tests`, `OK (skipped=1)`.
- Long soak completion intentionally moved to `T55` after explicit stop request from user.

## T55 Final Closure
- Pre-closure QA artifact:
  - `codex/projects/nordhold/worklogs/t55-post-t54-acceptance/t55-acceptance-20260226_192346/acceptance_summary.json`
  - result: `overall_pass=true` (`py_compile`, `unittest`, `web_build`, `exe_smoke` all pass).
- Full soak summary:
  - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_193004.summary.json`
  - `duration_s=1800`, `iterations=1800`.
- Soak metrics:
  - `endpoint_cycle_failures=0`,
  - `status_not_memory_count=1800`,
  - `memory_connected_false_count=1800`,
  - `last_mode=degraded`,
  - `last_reason=memory_unavailable_no_replay`,
  - `max_cycle_latency_ms=64.3`.
- Result:
  - `T55` is closed in canonical tracker files.

## T56 Current State (`in_progress`)
- Initial blocker snapshot (`run_id=20260226_203000`):
  - game process exists: `NordHold.exe` (`pid=9364`),
  - precheck degraded: `reason=process_found_but_admin_required`, `memory_connected=false`,
  - full soak did not start in that attempt.
- Latest partial run (`run_id=20260226_212616`):
  - precheck passed:
    - `mode=memory`,
    - `reason=ok`,
    - `memory_connected=true`,
  - soak run started with `DurationS=1800`, `PollMs=1000`,
  - run was interrupted by user at `1627/1800s`,
  - `summary.json` was not generated,
  - current status at capture:
    - `mode=degraded`,
    - `reason=memory_snapshot_failed:ReadProcessMemory failed: addr=0x56ad0004 size=4 read=0 winerr=299`.
- Soak runner hardening applied after partial-run data-loss gap:
  - `scripts/run_nordhold_live_soak.ps1` now:
    - writes `*.partial.json` on each cycle,
    - always persists final `*.summary.json` in `finally`,
    - includes interruption metadata (`completed`, `interrupted`, `elapsed_s`, `aborted_reason`).
  - smoke validation:
    - `run_id=nordhold-live-soak-20260226_220452`
    - artifacts:
      - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_220452.summary.json`
      - `codex/projects/nordhold/runtime/logs/nordhold-live-soak-20260226_220452.partial.json`.
- Evidence:
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/REPORT.md`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_203000/03_diagnostic_attempt.json`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/PARTIAL_REPORT.md`
  - `/mnt/c/Users/lenovo/Documents/cursor/codex/projects/nordhold/worklogs/t56-memory-soak/20260226_212616/PARTIAL_REPORT.json`
- Pending next step:
  - rerun full T56 soak (`DurationS=1800`, `PollMs=1000`) with game kept running for full duration and archive summary/logs.
