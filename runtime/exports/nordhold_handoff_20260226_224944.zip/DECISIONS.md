# DECISIONS.md

## D-001: Single operational path
- Date: 2026-02-24
- Decision: Run VMware lab operations only from `ansible-lx1.mgmt.local` and only through `scripts/ansible-logrun.sh`.
- Reason: auditability and deterministic artifacts.

## D-002: Preflight truth gates remain mandatory
- Date: 2026-02-24
- Decision: DNS/NTP/entropy/nested-network checks stay enforced before deploy.
- Reason: repeated firstboot and deployment instability without these gates.

## D-003: Outer gate handling without creds
- Date: 2026-02-24
- Decision: keep outer auto-gate disabled until creds exist; require explicit manual confirmation variables.
- Reason: avoid false confidence while still keeping explicit operator acknowledgment.

## D-004: TDD-first for deploy policy changes
- Date: 2026-02-24
- Decision: blocker/inject/recovery policy updates require unit tests first.
- Reason: regressions were caused by untested runtime-policy changes.

## D-005: Safe default over destructive runtime recovery
- Date: 2026-02-25
- Decision: disable risky fallback defaults for fresh runs:
  - `vmware_lab_ovfenv_govc_inject_enabled: false`
  - `vmware_lab_fe80_watchdog_reset_enabled: false`
- Reason: old pattern led to unstable loops and corrupted guest states in failed attempts.

## D-006: Canonical agent-sync files
- Date: 2026-02-25
- Decision: treat `CONVENTIONS.md`, `STATUS.md`, `TASKS.md`, `DECISIONS.md` as short authoritative context for both agents.
- Reason: existing project information is valid but heavily fragmented.

## D-007: No-workaround deploy policy
- Date: 2026-02-25
- Decision: if deploy ends in `FAIL`, the next action is always TDD root-cause cycle (forensics -> plan/doc -> code -> tests -> rerun). Temporary bypasses are forbidden.
- Reason: repeated "retry/bypass" behavior previously hid root causes and increased recovery cost.

## D-008: Transport verification source of truth
- Date: 2026-02-25
- Decision: validate `guestinfo.ovfEnvironmentTransport` from `govc vm.info -e` output, not from `govc vm.info -json`.
- Reason: in this contour `vm.info -json` omits `guestinfo.*` keys, which caused false `transport=unset` loop despite successful `vm.change`.

## D-009: Progress signal hardening for OVF blocker
- Date: 2026-02-25
- Decision: do not promote OVF progress based only on target port liveness while blocker status is `TOOLSDEPLOYPKG_IDLE`.
- Reason: this produced false `progress_seen=1` and an infinite blocker loop (`retry_count` grew without convergence).

## D-010: Entropy strict mode kept, threshold aligned to kernel pool size
- Date: 2026-02-25
- Decision: keep `vmware_lab_preflight_fail_on_low_entropy: true`, set project threshold `vmware_lab_preflight_entropy_min: 256`.
- Reason: strict gate remains mandatory while matching host reality (`entropy_avail/poolsize=256`) to avoid impossible threshold (`1000`) false-fails.

## D-011: Postcheck/acceptance only after full PASS
- Date: 2026-02-25
- Decision: do not run postcheck or acceptance when full deploy exits non-zero.
- Reason: failed full runs must go directly to forensics and TDD root-cause cycle; postcheck on failed state adds noise.

## D-012: v9 contracts are baseline, next fail handled as new root cause
- Date: 2026-02-25
- Decision: treat four implemented contracts (firstboot guard, entropy strict, PNID lock, deterministic mode) as locked baseline for all next runs.
- Reason: `full-v9` still failed with `no_guest_login` pattern, so next cycle must target that root cause without rolling back new contracts.

## D-013: Stage2 success criteria moved from OVF-only to health contract
- Date: 2026-02-25
- Decision: `ovfenv_len=0` is diagnostic only; hard-fail is allowed only by dedicated policies (`no_guest_login dead-ports/max-runtime`) or by Stage2 health timeout contract.
- Contract:
  - required green signals: `VAMI API`, `expected IPv4`, `firstboot signal` (all required by default),
  - if required signals are not green before timeout (`720s`) -> controlled fail with explicit `stage2_health_fail_reason`,
  - report must include `stage2_health_*` snapshot fields.
- Reason: repeated false negatives came from narrow OVF-only gate in nested runtime where OVF/guestinfo visibility is timing-sensitive.

## D-014: vCenter task/event timeline source for weekly report
- Date: 2026-02-25
- Decision: collect vCenter task/event timeline through SOAP SDK (`/sdk`, `QueryEvents`) and treat REST task/event endpoints as optional.
- Reason: in this contour REST task/event URLs are unstable (`404`), while SOAP `QueryEvents` is consistently readable with current RBAC.

## D-015: Correlation policy for weekly incident chains
- Date: 2026-02-25
- Decision:
  - host/FQDN is the primary correlation key;
  - default time window is `30 minutes`;
  - confidence tiers are `high >= 0.55`, `low/medium >= 0.35` (below threshold dropped);
  - low-confidence chains are shown with explicit flag and excluded from high-confidence KPI.
- Reason: this preserves actionable cross-source links while avoiding KPI inflation from weak temporal matches.

## D-016: Dual markdown styles for weekly report
- Date: 2026-02-25
- Decision: keep two markdown output styles in weekly script:
  - `detailed` for full technical dump,
  - `human` for concise managerial readability.
- Reason: one output is too noisy for status communication, while detailed diagnostics are still needed for engineering follow-up.

## D-017: Actor matching policy for user-focused slices
- Date: 2026-02-25
- Decision: actor focus matching is based on principal normalization across domains:
  - `DOMAIN\\user` -> `user`
  - `user@domain` -> `user`
  - `user` -> `user`
- Reason: operational user identity should be tracked independent of domain aliasing in different systems.

## D-018: Source-aware actor aliasing for `e.romanov`
- Date: 2026-02-25
- Decision: apply actor aliases by source using `data/correlation/actor_aliases.json`:
  - `vcenter_events`/`zabbix`: focus on `e.romanov` principal;
  - `ansible`/`loginsight`: include both `e.romanov` and `root`.
- Reason: in this contour Linux operational traces often appear as `root`, while Windows/Zabbix/vSphere actor identity is typically domain user principal.

## D-018: K8S correlation rollout isolation and canonical event
- Date: 2026-02-25
- Decision:
  - run K8S dedup correlations with per-cluster host-group isolation (`star-cluster` and `cluster-sndbx-v6` separated),
  - keep `Deployment replicas mismatch` as canonical signal,
  - dedup `Replicaset mismatch` via symmetric pair rules (both old/new order variants).
- Reason: event order is mixed in runtime, and cluster isolation is required to avoid cross-cluster false auto-closures.

## D-019: Ansible controller canonical workspace and backup hygiene
- Date: 2026-02-25
- Decision:
  - canonical workspace on `ansible-lx1` is `/etc/ansible/playbooks` (roles in `/etc/ansible/playbooks/roles`);
  - legacy `playbooks` subdirectory is deprecated and must not be recreated;
  - backup artifacts in working directories must follow cleanup/retention policy (no unbounded accumulation).
- Reason: this removes path fragmentation and prevents recurring workspace pollution from unmanaged backup files.

## D-020: IT Services baseline model = Variant B (Signal-First Ops)
- Date: 2026-02-25
- Decision:
  - initialize `service.list` with root `STAR Production Health`;
  - use 4 operational layers (`Data`, `Compute`, `Container`, `Search`);
  - define leaf services via stable runtime tags (`target`, `scope`, `namespace`);
  - keep default service algorithm `1` for this rollout.
- Reason: this gives immediate actionable operations view with minimal tagging prerequisites and keeps a clean path to a later business-SLA layer.

## D-021: Namespace exclusion limitation in service problem tags
- Date: 2026-02-25
- Decision:
  - accept current API constraint where `problem_tags.operator` supports only `0` (equals) and `2` (contains);
  - implement `K8S other namespaces` as broad `target=kubernetes state` until negative matching (`!=`) or richer tags are introduced.
- Reason: strict filter `namespace != star-services` is not expressible in current Zabbix service tag operators.

## D-022: Period-sensitive infra collectors for weekly/monthly reports
- Date: 2026-02-25
- Decision:
  - Zabbix event collection uses adaptive time-window splitting instead of fixed `limit=200`.
  - vCenter SOAP event collection uses windowed `QueryEvents` with split-on-saturation and explicit partial-output warnings.
  - Report metrics must expose collector behavior:
    - `zabbix_event_query_calls`, `zabbix_events_truncated`,
    - `vcenter_events_query_calls`, `vcenter_events_split_windows`, `vcenter_events_truncated`.
- Reason: monthly and weekly ranges must produce period-sensitive infra slices rather than identical “latest N” snapshots, while still surfacing when source-side caps force partial data.

## D-023: Nordhold calculator baseline architecture (offline-first + versioned rules)
- Date: 2026-02-25
- Decision:
  - keep Nordhold source-of-truth in `codex/projects/nordhold`;
  - implement wave calculator as offline-first split:
    - web UI (React+TS + worker),
    - local API bridge (FastAPI),
    - versioned dataset/rules layer (`data/versions/*`);
  - keep three runtime modes in one contract:
    - `expected`,
    - `combat`,
    - `monte_carlo`;
  - keep live-read path non-blocking:
    - if memory signatures are unavailable for current build, switch to replay fallback (`degraded`) without stopping timeline analytics.
- Reason:
  - game mechanics and balance are patch-sensitive, so formulas and catalogs must be data-driven and versioned;
  - interactive planning requires low-latency local recomputation;
  - memory-read is inherently fragile across builds and must not break the whole calculator.

## D-024: Nordhold Live Memory v1 contract (profile-driven + safe degrade)
- Date: 2026-02-25
- Decision:
  - memory-read path is profile-driven via `memory_signatures.json` (`schema_version=live_memory_v1`);
  - supported field sources are `address` and `pointer_chain` with typed reads;
  - profile may define explicit `pointer_size` (`4|8`) for pointer-chain width;
  - unresolved signatures are explicit (`address=0x0`, `unresolved=true`) and must force non-blocking degrade, not crash.
- Reason:
  - build-to-build signature drift is expected; the system must remain operable in replay/synthetic modes while signatures are being recalibrated.

## D-025: Nordhold live bring-up uses calibration overlay candidates
- Date: 2026-02-26
- Decision:
  - keep `memory_signatures.json` default profile unresolved until build-specific addresses are proven;
  - use external calibration candidate overlays (`calibration_candidates_path` + `calibration_candidate_id`) for live runtime bring-up;
  - promote a candidate only after live API chain confirms `mode=memory` and stable snapshot fields.
- Reason:
  - this keeps baseline datasets patch-safe while allowing rapid live validation against currently running game builds.

## D-026: Cross-runtime deterministic numeric serialization for golden parity
- Date: 2026-02-26
- Decision:
  - normalize floating-point values in realtime result serialization (`EvaluationResult.to_dict`) via deterministic rounding and signed-zero cleanup;
  - treat serialized output as canonical for golden regression across Linux/Windows runtimes.
- Reason:
  - monte-carlo aggregates showed sub-nanorange float drift across runtimes, which broke byte-level golden checks despite identical logic.

## D-027: Calibration candidate generation is scanner-driven, not manual-only
- Date: 2026-02-26
- Decision:
  - scanner workflow now includes `build-calibration-candidates` to produce LiveBridge-compatible candidate overlays directly from snapshot artifacts;
  - API exposes candidate inspection (`GET /api/v1/live/calibration/candidates`) to keep candidate selection transparent before live connect.
- Reason:
  - this removes repetitive manual JSON assembly and shortens the loop between scan artifacts and usable live memory profiles.

## D-028: Live session control is UI-first with bounded auto-reconnect
- Date: 2026-02-26
- Decision:
  - frontend is the primary operator surface for live attachment:
    - connect payload to `/api/v1/live/connect` includes process/admin/profile/calibration/replay fields;
    - candidate discovery uses `/api/v1/live/calibration/candidates`;
  - frontend may auto-retry connect on a bounded interval only while mode is not `memory`.
- Reason:
  - this removes manual API-call dependency during gameplay sessions and shortens attach time when game starts after calculator.

## D-029: Windows runtime distribution includes dedicated EXE launcher
- Date: 2026-02-26
- Decision:
  - ship Nordhold runtime with `PyInstaller` launcher output:
    - `runtime/dist/NordholdRealtimeLauncher/NordholdRealtimeLauncher.exe`;

## D-030: Ansible modernization treats non-playbook YAML as pass-through
- Date: 2026-02-26
- Decision:
  - during `T52` wrapper migration, only files that are actual playbooks (list of plays with `hosts`) are wrapped;
  - non-playbook YAML files remain unchanged and are tracked in manifest with `status=non_playbook_or_no_hosts`.
- Affected files:
  - `hosts.vmware.yml`,
  - `starpro_dev_websites.yml`,
  - `starpro_dev_websites_new.yml`,
  - `starpro_prod_websites.yml`,
  - `vmware_nested_lab_test_vm1.yml`.
- Reason:
  - forcing wrappers on inventory/vars-style YAML breaks syntax and runtime semantics.
  - launcher initializes bundled runtime paths via:
    - `NORDHOLD_PROJECT_ROOT`,
    - `NORDHOLD_WEB_DIST`,
    - frozen fallback probing (`exe dir`, `_internal`, parent).
- Reason:
  - this gives a direct Windows `exe` start path while preserving offline-first data/web loading in bundled mode.

## D-030: Live memory schema v2 with deterministic calibration recommendation
- Date: 2026-02-26
- Decision:
  - keep memory signature parser backward-compatible for both:
    - `live_memory_v1`,
    - `live_memory_v2`;
  - formalize combat field sets:
    - required: `current_wave`, `gold`, `essence`,
    - optional: additional combat telemetry fields (schema-driven);
  - recommendation algorithm for calibration candidates is fixed:
    - preferred candidate only if valid (all required fields resolved),
    - else choose max resolved required combat fields,
    - tie-break with `active_candidate_id`, then source order;
  - scanner-generated candidate payloads move to:
    - `nordhold_memory_calibration_candidates_v2`,
    - include recommendation support metadata and optional combat-field snapshot sources.
- Reason:
  - this keeps old datasets usable while enabling richer deep-extract calibration and deterministic candidate auto-selection.

## D-031: Combat-first snapshot contract uses fixed keys with deterministic defaults
- Date: 2026-02-26
- Decision:
  - `GET /api/v1/live/snapshot` must always expose these exact `build.raw_memory_fields` keys:
    - `base_hp_current`, `base_hp_max`, `leaks_total`, `enemies_alive`, `boss_alive`,
    - `boss_hp_current`, `boss_hp_max`, `wave_elapsed_s`, `wave_remaining_s`,
    - `barrier_hp_total`, `enemy_regen_total_per_s`, `is_combat_phase`;
  - unresolved values must not break polling/simulation and fall back deterministically:
    - numeric fields -> `0`,
    - boolean fields -> `false`;
  - `active_required_fields` in status represents enforced required field set for the active mode/profile.
- Reason:
  - this removes ambiguity between UI aliases and backend payloads, keeps degraded/replay behavior deterministic, and stabilizes wave analytics across partial/bitten calibration profiles.

## D-032: Composite signature profile ids are transport-only, connect resolves base profile id
- Date: 2026-02-26
- Decision:
  - frontend must normalize outgoing `signature_profile_id` to base profile id when status contains calibrated
    composite ids (`profile@candidate`);
  - backend `LiveBridge.connect` must tolerate composite ids with deterministic fallback chain:
    - requested id,
    - base id before `@`,
    - auto profile selection by process name.
- Reason:
  - live status may legitimately expose calibrated composite profile ids, but memory signature catalog ids are base profile ids; without normalization/fallback, reconnect loops fail with false `Requested signature profile not found`.

## D-033: Admin-required attach must report explicit reason without fallback overwrite
- Date: 2026-02-26
- Decision:
  - when `require_admin=true` and current context is not elevated, `LiveBridge.connect` returns immediately with:
    - `mode=degraded`,
    - `reason=process_found_but_admin_required`;
  - this reason must not be overwritten by terminal fallback `memory_unavailable_no_replay`.
- Reason:
  - deterministic diagnostics are required for realtime live-debug workflow; masked reasons waste calibration/debug cycles and mislead operator actions.

## D-034: Combat snapshot fallback inference for partial deep-extract profiles
- Date: 2026-02-26
- Decision:
  - when direct `leaks_total` is not present in raw memory payload, infer:
    - `leaks_total = max(0, base_hp_max - base_hp_current)`;
  - when direct `is_combat_phase` is not present, infer:
    - `is_combat_phase = enemies_alive > 0`.
- Reason:
  - live deep-extract is incremental; this keeps combat dashboard useful while optional memory signatures are only partially calibrated.

## D-035: HP-first optional field calibration is promoted to autoload candidate bundle
- Date: 2026-02-26
- Decision:
  - generated optional `player_hp` + `max_player_hp` addresses are included in the latest
    `memory_calibration_candidates_autoload.json`;
  - current live auto-discovery should prefer this newest autoload artifact by mtime.
- Reason:
  - this unlocks immediate base-HP telemetry (`base_hp_current/base_hp_max`) without waiting for full combat-field extraction.

## D-036: Deep-probe reports are compact by default for long live sessions
- Date: 2026-02-26
- Decision:
  - `nordhold_combat_deep_probe.py` keeps full per-tick samples disabled by default;
  - full sample dumps are opt-in via `--include-samples`;
  - long-probe launcher must create timestamped artifact run directories instead of fixed output paths.
- Reason:
  - writing full sample matrices for long probes can produce very large JSON files and slows iteration; summary-first output keeps extraction loops stable and predictable.

## D-037: Optional combat-field promotion is report-driven
- Date: 2026-02-26
- Decision:
  - promotion of optional combat fields is done from deep-probe reports using
    `scripts/nordhold_promote_deep_probe_candidates.py`;
  - source of truth for required snapshot metas remains the source candidates payload (`source_snapshot_meta_paths`);
  - selected optional fields are merged from `report.summary.selected_meta.*.meta_path` and rebuilt through
    `build_calibration_candidates_from_snapshots(...)`.
- Reason:
  - this keeps the promotion flow deterministic and eliminates manual JSON editing between probe output and live-attach candidate updates.

## D-038: T53 swarm ownership and merge windows
- Date: 2026-02-26
- Decision:
  - for T53, ownership is strict: only project tracker files and canonical sync files
    (`TASKS.md`, `STATUS.md`, `DECISIONS.md`) are edited in this bootstrap stage;
  - implementation merge windows are fixed and sequential:
    - `backend+sim` -> `frontend` -> `packaging/docs`.
- Reason:
  - this reduces cross-agent conflicts and keeps integration order deterministic during swarm execution.

## D-039: T53 API additions are locked as additive with backward compatibility
- Date: 2026-02-26
- Decision:
  - lock the new T53 API surface as additive:
    - `POST /api/v1/live/autoconnect`,
    - `GET /api/v1/dataset/version`,
    - `GET /api/v1/dataset/catalog`,
    - `GET /api/v1/run/state`,
    - `GET /api/v1/events`;
  - keep backward compatibility policy:
    - existing `/api/v1/live/*` contracts stay valid,
    - new fields are optional for clients,
    - clients can migrate to `run/state + events` without breaking legacy flows.
- Reason:
  - finalize T53 integration without regressing existing API consumers.

## D-040: Live soak execution is standardized via dedicated scripts
- Date: 2026-02-26
- Decision:
  - standardize live soak execution with dedicated scripts:
    - `scripts/run_nordhold_live_soak.ps1` (bounded soak with summary JSON),
    - `scripts/stop_nordhold_live_soak.ps1` (explicit stop flow by port/script match);
  - keep soak results in `runtime/logs` as `nordhold-live-soak-*.summary.json`;
  - if soak is interrupted by operator request, treat it as non-failure and resume in a dedicated follow-up task.
- Reason:
  - avoids one-off ad-hoc scripts in logs folders, keeps soak runs reproducible, and preserves deterministic operational flow for acceptance checks.

## D-041: T52 strict gates use manifest-scope lint and canonical ansible-lint debt tracking
- Date: 2026-02-26
- Decision:
  - keep non-playbook YAML files in manifest with `status=non_playbook_or_no_hosts` and exclude them from playbook syntax gates;
  - enforce syntax gate on all refactored canonical playbooks (`158`) only;
  - run `yamllint` on manifest scope (`legacy + canonical refactored`) with strict config adjusted for Ansible sequence indentation;
  - run `ansible-lint` on canonical playbook dirs only and track debt reduction against this stable scope;
  - keep required collections installed on controller for deterministic module resolution:
    - `ansible.posix`,
    - `community.docker`,
    - `community.general`,
    - `community.vmware`,
    - `ansible.windows`.
  - evidence (`b03` -> `b05`):
    - yamllint run_id: `20260226_171444-t52-p2-yamllint-b03-1772126084727437152` (`exit_code=0`);
    - syntax run_id: `20260226_171446-t52-p2-syntax-b03-1772126086899961625` (`exit_code=0`);
    - ansible-lint run_id: `20260226_171555-t52-p2-ansible-lint-b03-1772126155254905949` with debt `1165`;
    - yamllint run_id: `20260226_172818-t52-p2-yamllint-b04-1772126898737955019` (`exit_code=0`);
    - syntax run_id: `20260226_172820-t52-p2-syntax-b04-1772126900969658497` (`exit_code=0`);
    - ansible-lint run_id: `20260226_172929-t52-p2-ansible-lint-b04-1772126969068494078` with debt `1152`;
    - ansible-lint run_id: `20260226_174115-t52-p2-ansible-lint-b05-1772127675216441848` with latest debt `987`.
- Reason:
  - this keeps gates strict but technically correct for mixed playbook/non-playbook top-level YAML and avoids false-negative failures from missing collections.
