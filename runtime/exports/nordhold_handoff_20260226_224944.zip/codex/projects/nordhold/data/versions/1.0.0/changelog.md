# Nordhold Dataset v1.0.0

- Build: `20985960`
- Date: 2026-02-25
- Source mix: `online + local_extract + manual`

## Notes
- Values marked with `provenance` are working hypotheses until confirmed by golden runs.
- Barrier processing defaults to separate layer (`barrier_inherits_armor=false`) for this dataset.
- Accuracy/block and armor/penetration default to linear subtraction model.
