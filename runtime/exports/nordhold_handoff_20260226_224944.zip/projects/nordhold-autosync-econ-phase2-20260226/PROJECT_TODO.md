# PROJECT_TODO.md

Updated: 2026-02-26 22:05 MSK

- [x] Execute `backend+sim` merge window for T53.
- [x] Execute `frontend` merge window for T53.
- [x] Execute `packaging/docs` merge window for T53.
- [x] Keep `DONE.md` and `ARTIFACTS.md` updated during execution.
- [x] Finalize canonical sync (`TASKS.md`, `STATUS.md`, `DECISIONS.md`) for T53 closure.
- [x] Add reusable soak run/stop scripts for post-T53 hardening.
- [x] Update README/RUNBOOK with soak procedure.
- [x] Re-run core validation suite in Windows `.venv`.
- [x] Complete full `30+ min` soak run and archive summary in tracker artifacts (`T55`).
- [x] Close `T55` in canonical trackers with QA + soak evidence.
- [x] Capture T56 blocker evidence (`run_id=20260226_203000`) with exact degraded reason.
- [x] Re-run T56 precheck to memory mode (`run_id=20260226_212616`): `mode=memory`, `memory_connected=true`, `reason=ok`.
- [x] Start T56 `DurationS=1800` soak (`run_id=20260226_212616`), capture partial result (`1627/1800s`, user stop, no `summary.json`).
- [x] Harden soak runner to persist progress on interrupted runs (`*.partial.json` checkpoints + always-on final summary in `finally`).
- [ ] Re-run full T56 soak (`DurationS=1800`, `PollMs=1000`) with game kept running for full duration and archive summary/logs.
- [ ] Finalize T56 canonical/project closure after successful soak evidence.
